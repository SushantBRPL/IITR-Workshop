@echo off
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"

TITLE Local AI Environment Setup
COLOR 0A

echo ========================================================
echo    LOCAL AI ^& RAG ENVIRONMENT SETUP (Windows 64-bit)
echo ========================================================
echo.

:: Check for Administrator Privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Not running with Administrator privileges.
    echo If Python is missing, automatic installation requires Admin rights.
    echo.
)

:: 1. Check Python
echo [*] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Python not found. Attempting automatic installation...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile 'python_installer.exe'"
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to download Python. Please install manually from python.org
        goto :error
    )
    echo [*] Installing Python silently...
    start /wait python_installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del python_installer.exe

    for /f "tokens=2*" %%A in ('reg query "HKLM\System\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYSTEM_PATH=%%B"
    for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"
    set "PATH=%SYSTEM_PATH%;%USER_PATH%;C:\Program Files\Python312\;C:\Program Files\Python312\Scripts\"
)

python --version
if %errorlevel% neq 0 (
    echo [ERROR] Python is still not accessible. Please reopen your terminal as Administrator.
    goto :error
)
echo [OK] Python is available.

:: 2. Virtual Environment
echo.
echo [*] Setting up virtual environment (.venv)...
if not exist ".venv" (
    python -m venv .venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        goto :error
    )
)
call .venv\Scripts\activate
echo [OK] Virtual environment active.

:: 3. Requirements
echo.
echo [*] Creating requirements.txt...
(
    echo pypdf^>=4.0
    echo fastembed^>=0.4
    echo ollama^>=0.4
    echo numpy^>=1.26
    echo jupyterlab^>=4.0
    echo ipykernel^>=6.0
) > requirements.txt

:: 4. Install Packages
echo.
echo [*] Installing packages...
python -m pip install --upgrade pip
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install packages. Check internet connection.
    goto :error
)
echo [OK] Packages installed successfully.

:: 5. Ollama
echo.
echo [*] Checking Ollama...
ollama --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Ollama not found in PATH. Skipping model pull.
    goto :success
)
ollama pull gemma3:1b

:success
echo.
echo ========================================================
echo    SETUP COMPLETED SUCCESSFULLY!
echo ========================================================
pause
exit /b 0

:error
echo.
echo ========================================================
echo    SETUP FAILED. Please check the error above.
echo ========================================================
pause
exit /b 1